package extraction;

public class AutoQuery {

}
