package extraction;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

/** Class for storing phrases and their count
 * 
 */
public class phraseList {

	Vector phrase ;
	Vector  <Integer> count ;
	
	public phraseList()
	{
		phrase = new Vector ();
		count= new Vector ();
	}
	
	public void clearPhrases()
	{
		phrase.clear();
		count.clear();
	}
	public void add_phrase(String words)
	{
		int index;
		if(phrase.contains(words))
		{
			index=phrase.indexOf(words);
			count.set(index,(Integer)count.get(index)+1);
		}
		else
		{
			phrase.add(words);
			count.add(1);
		}
	}
	public phraseList (List l)
	{
		Iterator i = l.iterator();
		String words ;
		int index;
		phrase = new Vector ();
		count= new Vector ();
		while(i.hasNext())
		{
			words =(String)i.next();
			
			if(phrase.contains(words))
			{
				index=phrase.indexOf(words);
				count.set(index,(Integer)count.get(index)+1);
			}
			else
			{
				phrase.add(words);
				count.add(1);
			}
		}
		System.out.println("Unique phrases in the field "+phrase.size());
	}
	
	//descending order sort
	public void sortByFrequency()
	{
		int temp;
		String temp1;
		for(int i=0;i<phrase.size();i++)
			for(int j=0;j<phrase.size()-1;j++)
			{
				
				//System.out.println(" wcomparing "+phrase.get(j) +" "+count.get(j)+ " and "+phrase.get(j+1)+" "+count.get(j+1) );
				//System.out.println(" comparing "+count.get(j)+ " and "+count.get(j-1) );
				//System.out.println(" icomparing "+j+ " and "+(j+1) );
				
				if(count.get(j)<count.get(j+1))
				{
					//System.out.println(" got in "+count.get(j)+ " and "+count.get(j-1) );
					temp=count.get(j);
					count.set(j, count.get(j+1));
					count.set(j+1, temp);
					
					temp1=(String)phrase.get(j);
					phrase.set(j, phrase.get(j+1));
					phrase.set(j+1, temp1);
				}
			}
		
	/*	for(int i =0 ;i<phrase.size();i++)
		{
			System.out.println("Phrase "+phrase.get(i)+" freq : "+count.get(i));
		}*/
	}
	
	public List returnTopK(int k)
	{
		ArrayList list = new ArrayList ();
		this.sortByFrequency();
		//int ctr=0;
		int current=count.get(0);
		if(k>phrase.size())
			k=phrase.size();
		for(int i=0;i<k ;i++)
		{
		/*	if(current!=count.get(i))
			{
				current=count.get(i);
				ctr++;
			}*/
			list.add(phrase.get(i));
			//i++;
		}
		System.out.println("Sending "+list.size()+" phrases");
		return list;
	}
	
	public void writeToFile(String file,String type)
	{
		try{
			BufferedWriter bw = new BufferedWriter (new FileWriter(new File(file),true));
			for(int i=0;i<phrase.size();i++)
				bw.write("\n"+type +"\t"+phrase.get(i)+"\t"+count.get(i));
			bw.close();
			
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}
